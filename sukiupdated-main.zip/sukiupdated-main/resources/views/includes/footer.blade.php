<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body >
<div class="container-fluid" style="background-color: #000; width: 100%;">
<div class="container">
<div class="row">
<div class="col-sm-3">
<div class="container">
<a class="navbar-brand" href="{{ url('/') }}" style="padding: 0px;">
<img src="{{ asset('img/sukilogo.jpg') }}" alt="SUKISPARES" style="height:60px;">
</a>
<p>We provide quality car spare parts, timely, efficiently and at affordable standardized prices.</p>

<p>Address: Adress-Trance Towers Tsavo Road, Nairobi<br>
Phone: (+254) 727 787878 (+254) 783 111 333<br>
Email: info@sukispares.com</p>
</div>
</div>
<div class="col-sm-3">
   <p>We provide quality car spare parts, timely, efficiently and at affordable standardized prices.</p>

<p>Address: Adress-Trance Towers Tsavo Road, Nairobi<br>
Phone: (+254) 727 787878 (+254) 783 111 333<br>
Email: info@sukispares.com</p>
</div>
<div class="col-sm-3">
   <p>We provide quality car spare parts, timely, efficiently and at affordable standardized prices.</p>

<p>Address: Adress-Trance Towers Tsavo Road, Nairobi<br>
Phone: (+254) 727 787878 (+254) 783 111 333<br>
Email: info@sukispares.com</p>
</div>
<div class="col-sm-3">
  <p>We provide quality car spare parts, timely, efficiently and at affordable standardized prices.</p>

<p>Address: Adress-Trance Towers Tsavo Road, Nairobi<br>
Phone: (+254) 727 787878 (+254) 783 111 333<br>
Email: info@sukispares.com</p>
</div>
    
</div> 
</div>    
</div>
<div class="container">
<div class="row">
 <div class="col-sm-6">
     2
 </div>
  <div class="col-sm-6">
     1
 </div>     
</div>
</div>
</body>
</html>
